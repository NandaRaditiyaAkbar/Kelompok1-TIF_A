<!-- start: Footer -->
	<div id="footer">
		
		<!-- start: Container -->
		<div class="container">
			
			<!-- start: Row -->
			<div class="row">

				<!-- start: About -->
				<div class="span3">
					
					<h3>Bakso Viral Jember</h3>
					<p>
                    Bakso Viral Jember adalah rumah makan yang menyediakan berbagai jenis bakso yang kekinian. Setiap menunya diberi nama yang tidak kalah unik untuk menarik minat pelanggan. Penjualannya melayani delivery dengan sistem pembayaran Cash On Delivery (COD)
					 </p>
						
				</div>
				<!-- end: About -->

				<!-- start: Photo Stream -->
				
				<!-- end: Photo Stream -->

				
				
			 
			<!-- end: Row -->	
			
		</div>
		<!-- end: Container  -->

	 