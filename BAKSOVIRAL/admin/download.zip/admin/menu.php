                    <br />
                    <ul class="sidebar-menu">
                        <li class="active">
                            <a href="index.php">
                                <i class="glyphicon glyphicon-dashboard"></i> <span>Dashboard</span>
                            </a>
                        </li>
                          
                        <li class="treeview">
                            <a href="#">
                                <i class="glyphicon glyphicon-link"></i>
                                <span>Produk Makanan</span>
                                <i class="fa fa-angle-left pull-right"></i>
                            </a>
                            <ul class="treeview-menu">
                                <li><a href="produk.php"><i class="fa fa-angle-double-right"></i> Produk Makanan</a></li>
                                <li><a href="input-produk.php"><i class="fa fa-angle-double-right"></i> Tambah Produk</a></li>
                            </ul>
                        </li>

                        <li class="treeview">
                            <a href="#">
                                <i class="glyphicon glyphicon-usd"></i> <span>Transaksi</span>
                                <i class="fa fa-angle-left pull-right"></i>
                            </a>
                            <ul class="treeview-menu">
                                <li><a href="404.php"><i class="fa fa-angle-double-right"></i> Data Pesanan</a></li>
                                <li><a href="404.php"><i class="fa fa-angle-double-right"></i> Konfirmasi Pembayaran</a></li>
                                <li><a href="404.php"><i class="fa fa-angle-double-right"></i> Status Pengiriman</a></li>
                            </ul>
                        </li>

                        <li class="treeview">
                            <a href="#">
                                <i class="glyphicon glyphicon-lock"></i> <span>Admin</span>
                                <i class="fa fa-angle-left pull-right"></i>
                            </a>
                            <ul class="treeview-menu">
                                <li><a href="admin.php"><i class="fa fa-angle-double-right"></i>Data Admin</a></li>
                                <li><a href="input-admin.php"><i class="fa fa-angle-double-right"></i>Tambah Admin</a></li>
                            </ul>
                        </li>

                        <li class="treeview">
                            <a href="#">
                                <i class="glyphicon glyphicon-file"></i> <span>Laporan</span>
                                <i class="fa fa-angle-left pull-right"></i>
                            </a>
                            <ul class="treeview-menu">
                                <li><a href="404.php"><i class="fa fa-angle-double-right"></i> Laporan Purchase Order</a></li>
                                <li><a href="404.php"><i class="fa fa-angle-double-right"></i> Laporan Product</a></li>
                                <li><a href="404.php"><i class="fa fa-angle-double-right"></i> Laporan Data Customer</a></li>
                            </ul>
                        </li>
                        </ul>
                       
                        
                        